-- 1.	Create tables for Customers, Products, Orders, and Sales with proper relationships (primary & foreign keys).

create database Akila_Final_Projrct;
use Akila_Final_Projrct;

CREATE TABLE Customers (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    address VARCHAR(100)
);

CREATE TABLE Products (
    product_id INT PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(50) NOT NULL,
    category VARCHAR(30),
    price DECIMAL(10,2) NOT NULL
);

CREATE TABLE Orders (
    order_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    order_date DATE NOT NULL,
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
);

CREATE TABLE Sales (
    sale_id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    product_id INT,
    quantity INT,
    total_price DECIMAL(10,2),
    FOREIGN KEY (order_id) REFERENCES Orders(order_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- ------------------------------------------------------------------------------------------------------------------

INSERT INTO Customers (name, email, phone, address) VALUES
('Alice Johnson', 'alice.johnson@email.com', '9876543210', '123 Maple St, NY'),
('Bob Singh', 'bob.singh@email.com', '9123456781', '450 Oak Dr, CA'),
('Carla Kumar', 'carla.kumar@email.com', '8991234509', '77 Willow Pl, TX'),
('David Lee', 'david.lee@email.com', '7000111234', '12 Palm St, FL'),
('Eva Chen', 'eva.chen@email.com', '8822299900', '98 Pine Ave, WA');

INSERT INTO Products (product_name, category, price) VALUES
('Bluetooth Speaker', 'Electronics', 1500.00),
('Running Shoes', 'Apparel', 2500.00),
('Coffee Maker', 'Home Goods', 4000.00),
('Smartphone', 'Electronics', 30000.00),
('Backpack', 'Accessories', 1800.00);

INSERT INTO Orders (customer_id, order_date) VALUES
(1, '2025-09-01'),
(2, '2025-09-01'),
(3, '2025-09-02'),
(4, '2025-09-03'),
(5, '2025-09-03'),
(1, '2025-09-04');

INSERT INTO Sales (order_id, product_id, quantity, total_price) VALUES
(1, 1, 2, 3000.00),
(2, 2, 1, 2500.00),
(3, 3, 1, 4000.00),
(4, 4, 2, 60000.00),
(5, 5, 2, 3600.00),
(6, 1, 1, 1500.00),
(6, 3, 2, 8000.00);

-- -------------------------------------------------------------------------------------------------------------------
-- Top 5 customers by total spending

SELECT 
    c.customer_id, c.name, SUM(s.total_price) AS total_spent
FROM 
    Customers c
JOIN Orders o ON c.customer_id = o.customer_id
JOIN Sales s ON o.order_id = s.order_id
GROUP BY c.customer_id, c.name
ORDER BY total_spent DESC
LIMIT 5;

-- Best-selling products

SELECT 
    p.product_id, p.product_name, SUM(s.quantity) AS units_sold
FROM 
    Products p
JOIN Sales s ON p.product_id = s.product_id
GROUP BY p.product_id, p.product_name
ORDER BY units_sold DESC
LIMIT 5;

-- Monthly revenue trend

SELECT 
    DATE_FORMAT(o.order_date, '%Y-%m') AS month,
    SUM(s.total_price) AS revenue
FROM 
    Orders o
JOIN Sales s ON o.order_id = s.order_id
GROUP BY month
ORDER BY month;

-- -------------------------------------------------------------------------------------------

-- Use GROUP BY + HAVING to find customers who bought more than 5 products.

SELECT 
    c.customer_id, c.name, COUNT(DISTINCT s.product_id) AS products_bought
FROM 
    Customers c
JOIN Orders o ON c.customer_id = o.customer_id
JOIN Sales s ON o.order_id = s.order_id
GROUP BY c.customer_id, c.name
HAVING COUNT(DISTINCT s.product_id) > 5;

-- --------------------------------------------------------------------------------------------

-- Use JOINs to combine order, customer, and product details.

SELECT 
    o.order_id, o.order_date, 
    c.name AS customer_name,
    p.product_name, p.category, s.quantity, s.total_price
FROM 
    Sales s
JOIN Orders o ON s.order_id = o.order_id
JOIN Customers c ON o.customer_id = c.customer_id
JOIN Products p ON s.product_id = p.product_id;


-- -----------------------------------------------------------------------------------------------

-- Create a view for management showing daily sales summary.

CREATE VIEW DailySalesSummary AS
SELECT 
    o.order_date,
    COUNT(DISTINCT o.order_id) AS order_count,
    SUM(s.quantity) AS total_items_sold,
    SUM(s.total_price) AS daily_revenue
FROM 
    Orders o
JOIN Sales s ON o.order_id = s.order_id
GROUP BY o.order_date;



