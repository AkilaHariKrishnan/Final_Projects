# generate_and_train.py
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report
)
import joblib
import os

# -----------------------
# 1. Generate synthetic dataset
# -----------------------
np.random.seed(42)
n = 2000

# numeric features
age = np.random.randint(18, 80, size=n)
monthly_charges = np.round(np.random.uniform(20, 150, size=n), 2)
total_minutes = np.round(np.random.uniform(0, 5000, size=n), 1)          # usage
num_complaints = np.random.poisson(0.5, size=n)

# categorical features
plans = np.random.choice(['Basic', 'Standard', 'Premium'], size=n, p=[0.4, 0.4, 0.2])
contract = np.random.choice(['Month-to-month', 'One-year', 'Two-year'], size=n, p=[0.6, 0.25, 0.15])
has_internet = np.random.choice(['Yes', 'No'], size=n, p=[0.8, 0.2])

# churn probability synthetic rule (just for demo)
base_prob = (
    0.2 * (monthly_charges / monthly_charges.max()) +
    0.15 * (total_minutes < 500).astype(int) +
    0.15 * (plans == 'Basic').astype(int) +
    0.2 * (contract == 'Month-to-month').astype(int) +
    0.1 * (num_complaints > 0).astype(int)
)
# clamp & sample churn
churn_prob = np.clip(base_prob, 0, 0.9)
churn = (np.random.rand(n) < churn_prob).astype(int)

df = pd.DataFrame({
    'age': age,
    'plan': plans,
    'contract': contract,
    'has_internet': has_internet,
    'monthly_charges': monthly_charges,
    'total_minutes': total_minutes,
    'num_complaints': num_complaints,
    'churn': churn
})

# Save raw CSV (optional)
os.makedirs('data', exist_ok=True)
df.to_csv('data/customer_churn_raw.csv', index=False)
print("Saved synthetic data to data/customer_churn_raw.csv")

# -----------------------
# 2. Load & clean
# -----------------------
data = pd.read_csv('data/customer_churn_raw.csv')
# quick cleaning steps:
# - remove duplicates
data = data.drop_duplicates()
# - handle missing (none in our synthetic set, but show approach)
data['plan'] = data['plan'].fillna('Unknown')
data['has_internet'] = data['has_internet'].fillna('No')
# - ensure types
data['age'] = data['age'].astype(int)
data['churn'] = data['churn'].astype(int)

# -----------------------
# 3. EDA: NumPy & Pandas
# -----------------------
print("\n--- Basic stats ---")
print(data.describe(include='all'))

# correlations for numeric features
numeric_cols = ['age', 'monthly_charges', 'total_minutes', 'num_complaints', 'churn']
corr = data[numeric_cols].corr()
print("\n--- Correlation matrix ---")
print(corr)

# Save correlation to CSV for inspection
corr.to_csv('data/correlation_matrix.csv')

# -----------------------
# 4. Visualizations (Matplotlib)
# -----------------------
os.makedirs('plots', exist_ok=True)

# churn counts
plt.figure(figsize=(6,4))
data['churn'].value_counts().plot(kind='bar')
plt.title('Churn counts (0 = retained, 1 = churned)')
plt.xlabel('Churn')
plt.ylabel('Count')
plt.tight_layout()
plt.savefig('plots/churn_counts.png')
plt.close()

# monthly_charges histogram
plt.figure(figsize=(7,4))
plt.hist(data['monthly_charges'], bins=30)
plt.title('Monthly Charges Distribution')
plt.xlabel('Monthly Charges')
plt.ylabel('Frequency')
plt.tight_layout()
plt.savefig('plots/monthly_charges_hist.png')
plt.close()

# churn vs plan (bar)
plt.figure(figsize=(7,4))
pd.crosstab(data['plan'], data['churn'], normalize='index').plot(kind='bar', stacked=True, legend=True)
plt.title('Churn rate by Plan')
plt.ylabel('Proportion')
plt.tight_layout()
plt.savefig('plots/churn_by_plan.png')
plt.close()

print("Saved plots to plots/*.png")

# -----------------------
# 5. Prepare data for modeling
# -----------------------
X = data.drop(columns=['churn'])
y = data['churn']

# Preprocessing: one-hot categorical, scale numeric
categorical_features = ['plan', 'contract', 'has_internet']
numeric_features = ['age', 'monthly_charges', 'total_minutes', 'num_complaints']


preprocessor = ColumnTransformer(transformers=[
    ('num', StandardScaler(), numeric_features),
    ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), categorical_features)

])

# train/test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

# -----------------------
# 6. Build pipelines & train models
# -----------------------
# Logistic Regression pipeline
pipe_lr = Pipeline(steps=[
    ('pre', preprocessor),
    ('clf', LogisticRegression(max_iter=1000, class_weight='balanced'))
])

# Random Forest pipeline
pipe_rf = Pipeline(steps=[
    ('pre', preprocessor),
    ('clf', RandomForestClassifier(n_estimators=200, random_state=42, class_weight='balanced'))
])

# Fit logistic
pipe_lr.fit(X_train, y_train)
y_pred_lr = pipe_lr.predict(X_test)
y_proba_lr = pipe_lr.predict_proba(X_test)[:,1]

# Fit random forest
pipe_rf.fit(X_train, y_train)
y_pred_rf = pipe_rf.predict(X_test)
y_proba_rf = pipe_rf.predict_proba(X_test)[:,1]

# Evaluate helper
def evaluate(name, y_true, y_pred, y_proba):
    print(f"\n--- {name} Evaluation ---")
    print("Accuracy:", accuracy_score(y_true, y_pred))
    print("Precision:", precision_score(y_true, y_pred))
    print("Recall:", recall_score(y_true, y_pred))
    print("F1:", f1_score(y_true, y_pred))
    print("ROC-AUC:", roc_auc_score(y_true, y_proba))
    print("Confusion Matrix:\n", confusion_matrix(y_true, y_pred))
    print("Classification Report:\n", classification_report(y_true, y_pred))

evaluate("Logistic Regression", y_test, y_pred_lr, y_proba_lr)
evaluate("Random Forest", y_test, y_pred_rf, y_proba_rf)

# Choose best by ROC-AUC
lr_auc = roc_auc_score(y_test, y_proba_lr)
rf_auc = roc_auc_score(y_test, y_proba_rf)
best_model = pipe_rf if rf_auc >= lr_auc else pipe_lr
best_name = "RandomForest" if rf_auc >= lr_auc else "LogisticRegression"
print(f"\nBest model: {best_name} (RF AUC={rf_auc:.3f}, LR AUC={lr_auc:.3f})")

# Save the best model
joblib.dump(best_model, 'model.joblib')
print("Saved model.joblib")

# Also save the preprocessor (first step) separately if needed
# (In our pipelines, preprocessor is embedded; we saved full pipeline so this is optional.)
