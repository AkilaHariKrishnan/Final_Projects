# app.py
from flask import Flask, render_template, request, jsonify
import joblib
import numpy as np
import pandas as pd

app = Flask(__name__)

# Load trained pipeline
model = joblib.load('model.joblib')

# Simple web form for input
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get form values
    try:
        age = int(request.form.get('age', 30))
        plan = request.form.get('plan', 'Standard')
        contract = request.form.get('contract', 'Month-to-month')
        has_internet = request.form.get('has_internet', 'Yes')
        monthly_charges = float(request.form.get('monthly_charges', 50.0))
        total_minutes = float(request.form.get('total_minutes', 1000.0))
        num_complaints = int(request.form.get('num_complaints', 0))
    except Exception as e:
        return jsonify({'error': 'Invalid input. ' + str(e)}), 400

    # Build DataFrame (single row)
    X_new = pd.DataFrame([{
        'age': age,
        'plan': plan,
        'contract': contract,
        'has_internet': has_internet,
        'monthly_charges': monthly_charges,
        'total_minutes': total_minutes,
        'num_complaints': num_complaints
    }])

    proba = model.predict_proba(X_new)[:, 1][0]
    pred = int(proba >= 0.5)

    return render_template('result.html', probability=round(float(proba)*100, 2), prediction=pred)

if __name__ == '__main__':
    app.run(debug=True)
