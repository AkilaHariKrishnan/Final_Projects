# generate_and_train.py
import os
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import joblib

# -------------------------------
# 1. Generate / Load Dataset
# -------------------------------
np.random.seed(42)

n = 300
data = pd.DataFrame({
    "study_hours": np.random.normal(5, 2, n).clip(0, 12),
    "attendance": np.random.randint(60, 101, n),
    "parent_education": np.random.choice(
        ["High School", "Bachelors", "Masters", "PhD"], size=n
    ),
    "gender": np.random.choice(["Male", "Female"], size=n),
})

# target variable (exam scores)
data["score"] = (
    2 * data["study_hours"]
    + 0.5 * data["attendance"]
    + data["parent_education"].map({
        "High School": 0,
        "Bachelors": 5,
        "Masters": 10,
        "PhD": 15
    })
    + np.random.normal(0, 5, n)
).clip(0, 100)

# Save raw dataset
os.makedirs("data", exist_ok=True)
data.to_csv("data/student_performance.csv", index=False)
print("✅ Saved dataset to data/student_performance.csv")

# -------------------------------
# 2. Data Cleaning
# -------------------------------
print("\n--- Data Info ---")
print(data.info())
print("\n--- Missing Values ---")
print(data.isnull().sum())

# -------------------------------
# 3. EDA with NumPy + Pandas
# -------------------------------
print("\n--- Statistical Summary ---")
print(data.describe())

print("\n--- Correlation Matrix ---")
print(data.corr(numeric_only=True))

# -------------------------------
# 4. Seaborn Visualizations
# -------------------------------
os.makedirs("plots", exist_ok=True)

plt.figure(figsize=(8, 6))
sns.heatmap(data.corr(numeric_only=True), annot=True, cmap="coolwarm")
plt.title("Correlation Heatmap")
plt.savefig("plots/correlation_heatmap.png")
plt.close()

plt.figure(figsize=(8, 6))
sns.boxplot(x="study_hours", y="score", data=data)
plt.title("Scores vs Study Hours")
plt.savefig("plots/boxplot_scores_vs_study_hours.png")
plt.close()

plt.figure(figsize=(8, 6))
sns.violinplot(x="gender", y="score", data=data)
plt.title("Scores by Gender")
plt.savefig("plots/violinplot_gender_vs_scores.png")
plt.close()

print("✅ Saved plots to plots/*.png")

# -------------------------------
# 5. Prepare Data for Modeling
# -------------------------------
X = data[["study_hours", "attendance", "parent_education", "gender"]]
y = data["score"]

# one-hot encode categorical vars
X = pd.get_dummies(X, drop_first=True)

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# -------------------------------
# 6. Train Models
# -------------------------------
lr = LinearRegression()
lr.fit(X_train, y_train)

rf = RandomForestRegressor(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)

# -------------------------------
# 7. Evaluate Models
# -------------------------------
def eval_reg(name, y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)   # manual RMSE calculation (no 'squared' arg)
    r2 = r2_score(y_true, y_pred)
    print(f"{name}: RMSE={rmse:.2f}, R2={r2:.2f}")
    return rmse, r2

print("\n--- Model Performance ---")
y_pred_lr = lr.predict(X_test)
y_pred_rf = rf.predict(X_test)

lr_rmse, lr_r2 = eval_reg("Linear Regression", y_test, y_pred_lr)
rf_rmse, rf_r2 = eval_reg("Random Forest", y_test, y_pred_rf)

# -------------------------------
# 8. Save Best Model
# -------------------------------
if rf_r2 > lr_r2:
    joblib.dump(rf, "model.joblib")
    print("✅ Saved best model: Random Forest -> model.joblib")
else:
    joblib.dump(lr, "model.joblib")
    print("✅ Saved best model: Linear Regression -> model.joblib")
