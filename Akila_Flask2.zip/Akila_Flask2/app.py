# app.py
from flask import Flask, render_template, request
import joblib
import pandas as pd

app = Flask(__name__)
model = joblib.load('model.joblib')  # must be in same folder

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        study_hours = float(request.form.get('study_hours', 4.0))
        attendance = float(request.form.get('attendance', 75.0))
        parent_edu = request.form.get('parent_edu', 'Bachelors')
        gender = request.form.get('gender', 'Female')
        extra_classes = request.form.get('extra_classes', 'No')
        sleep_hours = float(request.form.get('sleep_hours', 7.0))
    except Exception as e:
        return f"Invalid input: {e}", 400

    X_new = pd.DataFrame([{
        'study_hours': study_hours,
        'attendance': attendance,
        'parent_edu': parent_edu,
        'gender': gender,
        'extra_classes': extra_classes,
        'sleep_hours': sleep_hours
    }])

    pred = model.predict(X_new)[0]
    pred = round(float(pred), 2)
    return render_template('result.html', prediction=pred)

if __name__ == '__main__':
    app.run(debug=True)
